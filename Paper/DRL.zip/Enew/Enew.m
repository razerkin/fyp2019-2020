function  Vtmin  = Enew( map )
load('data_channel_MU1_BS6.mat');

W=16;
n_0=1e-8;
k=0.08;
uLmax=3; 
Num_BS=5;
Num_MU=1;

%E_loc=5*ones(1,Num_MU);
%E_ser=10*ones(1,Num_BS);

P_loc=0.5*ones(1,Num_MU);
%P_ser=0.1*ones(1,Num_BS);

ui=[12,15,11,10,9,8];
ui(map(6))=[];
% ui(map(7))=0;
% ui(find(ui==0))=[];
% ui(find(ui==0))=[];
g_Bi(map(6))=[];
% g_Bi(map(7))=0;
% g_Bi(find(g_Bi==0))=[];
% g_Bi(find(g_Bi==0))=[];
Cgain_B=zeros(Num_MU,Num_BS);
% for i=1:1:Num_MU
%     Cgain_B(i,:)=sort(g_Bi(i,:),'descend');   %���潵��
% end
% % ����ϵ�� 
% vec_B=[];
% for i=1:1:Num_MU
%     for j=1:1:Num_BS
%         if j==1
%            vec_B(i,j)=W*n_0*(1/Cgain_B(i,j));
%         else
%            vec_B(i,j)=W*n_0*(1/Cgain_B(i,j)-1/Cgain_B(i,j-1));
%         end
%     end
% end

Cgain_B(1,:)=sort(g_Bi(1,:),'descend');   %���潵��

% ����ϵ�� 
vec_B=[];
    for j=1:1:Num_BS
        if j==1
           vec_B(1,j)=W*n_0*(1/Cgain_B(1,j));
        else
           vec_B(1,j)=W*n_0*(1/Cgain_B(1,j)-1/Cgain_B(1,j-1));
        end
    end


Matrix=tril(ones(Num_BS,Num_BS),0); 
T_band=[];
T_band=0.1:1e-1:2;

Tmax=[2 3 4 5 6 0];
Stot=[5 6 7 8 9 0];

Num_map=size(map,2);
for m=1:1:Num_map
S_tot(m)=Stot(find(map==m));
T_max(m)=Tmax(find(map==m));
end

S_tot(find(S_tot==0))=[];
T_max(find(T_max==0))=[];

Vtmin=100000;

    for j=1:1:size(T_band,2)
        temp_t=T_band(j);
        cvx_begin quiet
        warning off
        variable s(Num_MU,Num_BS);
        minimize (((vec_B(1,1)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,1)))+...
               (vec_B(1,2)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,2)))+...
               (vec_B(1,3)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,3)))+...
               (vec_B(1,4)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,4)))+...
               (vec_B(1,5)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,5)))-W*n_0/Cgain_B(1,Num_BS))*temp_t+...
               k*(pow_pos((S_tot(1,1)-s(1,1)),3)*(1/T_max(1,1)*1/T_max(1,1))+...
                   pow_pos((S_tot(1,2)-s(1,2)),3)*(1/T_max(1,2)*1/T_max(1,2))+...
                   pow_pos((S_tot(1,3)-s(1,3)),3)*(1/T_max(1,3)*1/T_max(1,3))+...
                   pow_pos((S_tot(1,4)-s(1,4)),3)*(1/T_max(1,4)*1/T_max(1,4))+...
                   pow_pos((S_tot(1,5)-s(1,5)),3)*(1/T_max(1,5)*1/T_max(1,5))));
        subject to
        (S_tot(1,1)-s(1,1))/T_max(1,1)+(S_tot(1,2)-s(1,2))/T_max(1,2)+(S_tot(1,3)-s(1,3))/T_max(1,3)+(S_tot(1,4)-s(1,4))/T_max(1,4)+(S_tot(1,5)-s(1,5))/T_max(1,5)<=uLmax;
         sum(S_tot(1,:)-s(1,:))>0;
         for q=1:1:Num_BS
                s(1,q)<=(T_max(1,q)-temp_t)*ui(1,q);
                s(1,q)>= 0;
         end
         ((vec_B(1,1)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,1)))+...
         (vec_B(1,2)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,2)))+...
         (vec_B(1,3)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,3)))+...
         (vec_B(1,4)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,4)))+...
         (vec_B(1,5)*exp(log(2)*(1/temp_t)*(1/W)*s(1,:)*Matrix(:,5)))-W*n_0/Cgain_B(1,Num_BS))<=P_loc(1,1);
     cvx_end
     star=cvx_optval;
     Vt1(j)=star;
     if Vt1(j)<Vtmin
       Vtmin=Vt1(j);
     end
    end

end
