# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 10:00:06 2017

@author: Administrator
"""

import numpy as np
import matlab
import matlab.engine


class problem(object):
    
    state_dim = 6
    action_dim = 6
    action_bound = [-3, 3]
    dt = 0.1
    def __init__(self):
        self.engine = matlab.engine.start_matlab()
        self.gain = 0

        self.O=np.random.random(6)
        
        self.betterO=self.O.copy()

        self.gain_MIN = 100000
        self.gain_min = 100000
        self.gain_MIN_para=self.O.copy()
        self.gain_his = []
        self.min_his= []
        self.on_goal=0
    def reset(self):
        self.O=np.random.random(6)
        
        #g=self.evaluate()
        #s = np.hstack((self.O,g/100,[1. if self.on_goal else 0.]))
        s = self.arg_sort()-3.5
        return s
    def arg_sort(self):
        return np.argsort(self.O)+1
    def step(self, action):
        done = False
        reward=0

        action = np.clip(action, *self.action_bound)
        for i in range(self.action_dim):
            self.O[i]+=action[i]*self.dt
           # if self.O[i]>1 or self.O[i]<0:
            #    self.O[i]=0.5
            
        #self.O=np.clip(self.O, *[0,1])    
        self.gain=self.evaluate()
        #s_=np.hstack((self.O,self.gain/100,[1. if self.on_goal else 0.]))
        s_ = self.arg_sort()-3.5
        if self.gain < self.gain_min:   
            self.gain_min = self.gain
            if self.gain_min < self.gain_MIN:
                self.gain_MIN = self.gain_min
                self.gain_MIN_para = np.argsort(self.O.copy())+1

        self.gain_his.append(self.gain)
        self.min_his.append(self.gain_min)
        
        reward = 11 - self.gain *100
        

       
        return s_, reward, done,self.gain_MIN,self.gain_MIN_para,self.gain
    def plot_gain(self):
        import matplotlib.pyplot as plt
        import pandas as pd
        import matplotlib as mpl
        
        gain_array = np.asarray(self.gain_his)
      #  gain_array2 = np.asarray(self.gain_his2)

            
            
        df = pd.DataFrame(gain_array)
        #df2 = pd.DataFrame(gain_array2)
        
#        ma = pd.rolling_mean(gain_array, 20)
#        mstd = pd.rolling_std(gain_array, 20)
        
        mpl.style.use('seaborn')
        fig, ax = plt.subplots(figsize=(15,8))
#        plt.plot(np.arange(len(gain_array))+1, gain_array, 'r')
        plt.plot(np.arange(len(gain_array))+1, df.rolling(60, min_periods=1).mean(),  'b')
        #plt.plot(np.arange(len(gain_array2))+1, df2.rolling(60, min_periods=1).mean(),  'r',label='learning rate 0.001')
        plt.fill_between(np.arange(len(gain_array))+1, df.rolling(60, min_periods=1).min()[0], df.rolling(60, min_periods=1).max()[0], color = 'b', alpha = 0.2)
        plt.ylabel('system utility')
        plt.xlabel('training steps')
        #plt.legend(loc='best')
        plt.grid(True)
        #plt.savefig('E:\\main4.eps')
        plt.show()
    def save_mat(self,save_name):
        import scipy.io as sio
        sio.savemat('./Data/%s'%save_name, {'data':self.gain_his})
    def evaluate(self):
        sortd=self.arg_sort()
        result = self.engine.Enew(matlab.double(list(sortd)))
        return result
    